﻿# age.py

def main():
    print("안녕하세요.")    
    age = int(input("나이를 입력하세요: "))
    print("입력하신 나이는 다음과 같습니다:", age)
    print("만나서 반가웠습니다.")
   
main()
