# main.py

def main():
    print("Simple Frame")

main()
