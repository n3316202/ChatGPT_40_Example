# if_else.py

def main():
    num = int(input("정수 입력: "))

    if num > 0:
        print("0보다 큰 수입니다.")
    else:
        print("0보다 크지 않은 수입니다.")
    

main()
