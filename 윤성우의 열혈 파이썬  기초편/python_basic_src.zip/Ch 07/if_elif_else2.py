﻿# if_elif_else2.py

def main():
    num = int(input("정수 입력: "))

    if num == 1:
        print("1을 입력했습니다.")
    elif num == 2:
        print("2를 입력했습니다.")
    elif num == 3:
        print("3을 입력했습니다.")
    else:
        print("1, 2, 3 아닌 정수 입력했습니다.")
    

main()
