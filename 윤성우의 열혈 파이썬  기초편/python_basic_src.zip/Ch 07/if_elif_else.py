﻿# if_elif_else.py

def main():
    num = int(input("정수 입력: "))

    if num > 0:
        print("0보다 큰 수입니다.")
    elif num < 0:
        print("0보다 작은 수입니다.")
    else:
        print("0으로 판단이 됩니다.")
    

main()
