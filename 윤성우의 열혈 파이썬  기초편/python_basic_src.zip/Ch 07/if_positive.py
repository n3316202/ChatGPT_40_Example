﻿# if_positive.py

def main():
    num = int(input("정수 입력: "))

    if num > 0:
        print("양의 정수입니다.")
    

main()
