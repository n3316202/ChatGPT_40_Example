def add(num1, num2):
    return num1 + num2

def min(num1, num2):
    return num1 - num2

def mul(num1, num2):
    return num1 * num2

def div(num1, num2):
    return num1 / num2

def main():
    print(add(5, 3))
    print(min(5, 3))
    print(mul(5, 3))
    print(div(5, 3))


main()
