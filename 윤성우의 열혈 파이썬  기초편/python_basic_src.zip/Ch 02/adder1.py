def adder(num1, num2):
    return num1 + num2


print(adder(5, 3))
