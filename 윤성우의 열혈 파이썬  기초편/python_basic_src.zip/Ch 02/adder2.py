def adder(num1, num2):
    return num1 + num2

def main():
    print(adder(5, 3))

main()
