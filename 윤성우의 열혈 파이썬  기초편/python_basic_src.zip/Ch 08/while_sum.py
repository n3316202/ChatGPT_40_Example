# while_sum.py

def main():
    i = 1
    sum = 0
    
    while i < 11:
        sum = sum + i        
        i = i + 1

    print("sum =", sum, end = ' ')
    

main()
