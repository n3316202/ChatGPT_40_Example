# while_basic.py

def main():
    cnt = 0
    
    while cnt < 3:
        print(cnt, end = ' ')
        cnt = cnt + 1

main()
