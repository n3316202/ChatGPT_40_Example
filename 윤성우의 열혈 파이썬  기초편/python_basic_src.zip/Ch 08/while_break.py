# while_break.py

def main():
    i = 0    
    while i < 100:
        print(i, end = ' ')
        i = i + 1
        if i == 20: 
            break 

main()
