# for_sum.py

def main():
    sum = 0
    for i in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]:
        sum = sum + i
    
    print("sum =", sum, end = ' ')

main()
