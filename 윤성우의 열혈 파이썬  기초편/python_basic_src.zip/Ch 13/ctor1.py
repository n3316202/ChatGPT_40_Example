﻿# ctor1.py

class Const:
    def __init__(self):
        print("new~")

def main():
    o1 = Const()
    o2 = Const()
   
main()
